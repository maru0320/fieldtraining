import axios from "axios";
import React, { useEffect, useState } from 'react';
import { jwtDecode } from 'jwt-decode';
import { useNavigate, Link } from "react-router-dom";
import Sidebar from "../../Sidebar";

const Gallery = () => {
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(true);
    const [galleries, setGalleries] = useState([]);
    const [affiliation, setAffiliation] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchInfo = async () => {
            try {
                const token = localStorage.getItem('token');
                if (!token) {
                    throw new Error('로그인 정보가 없습니다.');
                }

                const decodedToken = jwtDecode(token);
                const userId = decodedToken.userId;
                const role = decodedToken.roles;

                // ROLE_NAME 변환
                let roleName = 'unknown';

                if (role.includes('ROLE_SCHOOL_MANAGER')) {
                    roleName = 'schoolManager';
                } else if (role.includes('ROLE_PROFESSOR')) {
                    roleName = 'professor';
                } else if (role.includes('ROLE_TEACHER')) {
                    roleName = 'teacher';
                } else if (role.includes('ROLE_STUDENT')) {
                    roleName = 'student';
                } else if (role.includes('ROLE_COLLEGE_MANAGER')) {
                    roleName = 'collegeManager';
                }

                // API 호출
                const affiliationResponse = await axios.get(`http://localhost:8090/api/gallery/affiliation/${userId}/${roleName}`);
                setAffiliation(affiliationResponse.data);
                console.log('기관 이름 정보: ', affiliationResponse.data);

                if (affiliationResponse.data) {
                    const galleriesResponse = await axios.get(
                        `http://localhost:8090/api/gallery/galleries/${affiliationResponse.data}`
                    );
                    console.log(galleriesResponse.data); // 데이터를 콘솔에 출력하여 확인
                    setGalleries(galleriesResponse.data); // 갤러리 목록 저장
                }
            } catch (err) {
                console.error('사용자 정보 불러오기 오류:', err);
                setError(err.message || '사용자 정보를 불러오는 중 오류가 발생했습니다.');
            } finally {
                setLoading(false);
            }
        };
        fetchInfo();
    }, []);

    const onClickGallerySave = () => {
        navigate("/gallery/galleryWrite");
    }

    return (
        <div className="gallery-wrapper">
            <Sidebar />
            <div className="gallery-container">
            <h2>갤러리</h2>
            {!loading && !error && galleries.length > 0 ? (
                <div className="gallery-section">
                    <ul>
                        {galleries.map((gallery) => (
                            <li key={gallery.boardID}>
                                {gallery.files && gallery.files.length > 0 ? (
                                    <ul>
                                        <li key={gallery.files[0].id}> {/* 첫 번째 파일만 표시 */}
                                            <img src={`http://localhost:8090${gallery.files[0].imgUrl}`} />
                                        </li>
                                    </ul>
                                ) : (
                                    <p>파일이 없습니다.</p>
                                )}
                                <Link to={`/gallery/galleryDetail/${gallery.boardID}`}> {/* BoardId를 URL 경로로 전달 */}
                                    {gallery.title}
                                </Link>
                                <p>{gallery.date}</p>
                            </li>
                        ))}
                    </ul>
                </div>
            ) : (
                <p>갤러리가 존재하지 않습니다.</p>
            )}
                <button onClick={onClickGallerySave}>작성하기</button>
            </div>
        </div>
    );
};

export default Gallery;
