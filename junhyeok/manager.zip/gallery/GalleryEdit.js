import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axiosInstance from '../../axiosInstance';
import { jwtDecode } from 'jwt-decode';

const GalleryEdit = () => {
    const [galleryDetail, setGalleryDetail] = useState(null);
    const [files, setFiles] = useState([]); // 여러 파일을 업로드할 상태로 변경
    const navigate = useNavigate();
    const { boardID } = useParams(); // URL에서 boardID 가져오기
    const token = localStorage.getItem("token");

    useEffect(() => {
        // 서버에서 갤러리 상세 정보 요청
        axiosInstance.get(`/api/gallery/${boardID}`)
            .then(response => {
                setGalleryDetail(response.data);
            })
            .catch(error => {
                console.error('갤러리 수정페이지 불러오기 오류', error);
            });
    }, [boardID]);  // boardID가 변경될 때마다 다시 요청

    if (!galleryDetail) {
        return <div>Loading...</div>;
    }

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setGalleryDetail((prevGallery) => ({
            ...prevGallery,
            [name]: value,
        }));
    };

    const handleFileChange = (e) => {
        const selectedFiles = e.target.files;  // 다중 파일 선택 가능
        if (selectedFiles) {
            setFiles([...files, ...selectedFiles]); // 기존 파일 목록에 새로 추가
        }
    };

    const handleFileDelete = (fileId) => {
        setGalleryDetail((prevDetail) => ({
            ...prevDetail,
            files: prevDetail.files.filter((file) => file.id !== fileId),
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const decodedToken = jwtDecode(token);
        const sub = decodedToken.sub;

        const formData = new FormData();

        formData.append("title", galleryDetail.title);  // 수정된 제목
        formData.append("writerName", sub);  // 수정된 작성자 => userId로 변경

        files.forEach((file) => {
            formData.append("files", file);  // 새로 업로드된 파일 추가
        });

        // 파일과 다른 데이터를 FormData로 서버로 전송
        axiosInstance.put(`/api/gallery/${boardID}`, formData, {
            headers: {
                "Content-Type": "multipart/form-data",  // 파일 전송을 위한 Content-Type 설정
            },
        })
        .then(response => {
            console.log('갤러리 수정 완료', response);
            alert('갤러리가 수정되었습니다.');
            navigate(`/gallery/galleryDetail/${boardID}`); // 수정 완료 후 상세페이지로 이동
        })
        .catch(error => {
            console.error('갤러리 수정 실패', error.response.data);
            alert('수정에 실패했습니다.');
        });
    };

    return (
        <div className="gallery-modify-container">
            <h2 className="gallery-modify-title">갤러리 수정</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>제목:</label>
                    <input
                        type="text"
                        name="title"
                        value={galleryDetail.title}
                        onChange={handleInputChange}
                        required
                    />
                </div>
                {/* 파일 업로드 */}
                <div>
                    <label>파일 업로드:</label>
                    <input
                        type="file"
                        multiple
                        onChange={handleFileChange} // 다중 파일 선택
                    />
                    {galleryDetail.files.length > 0 ? (
                        <div>
                            <h4>현재 파일:</h4>
                            <ul>
                                {galleryDetail.files.map((file) => (
                                    <li key={file.id}>
                                        <img src={file.imgUrl} alt={file.originalName} width={100} />
                                        <button type="button" onClick={() => handleFileDelete(file.id)}>
                                            삭제
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ) : (
                        <p>파일 없음</p>
                    )}
                </div>
                <button type="submit">수정하기</button>
            </form>
        </div>
    );
};

export default GalleryEdit;
