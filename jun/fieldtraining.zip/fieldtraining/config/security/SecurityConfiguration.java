package com.fieldtraining.config.security;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;

import com.fieldtraining.service.TokenBlacklistService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Configuration
public class SecurityConfiguration {

	private final JwtTokenProvider jwtTokenProvider;
	private final TokenBlacklistService tokenBlacklistService;
	
	@Autowired
	public SecurityConfiguration(JwtTokenProvider jwtTokenProvider, TokenBlacklistService tokenBlacklistService){
		this.jwtTokenProvider = jwtTokenProvider;
		this.tokenBlacklistService = tokenBlacklistService;
	}
	
	static {
        // 비동기 요청에서 인증 정보를 유지하기 위해 설정
        SecurityContextHolder.setStrategyName(SecurityContextHolder.MODE_INHERITABLETHREADLOCAL);
    }

	
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity httpSecurity) throws Exception {
			return httpSecurity
					.sessionManagement(sessionManagement -> sessionManagement
							.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                    .cors(corsCustomizer -> corsCustomizer.configurationSource(new CorsConfigurationSource() {
                        @Override
                        public CorsConfiguration getCorsConfiguration(HttpServletRequest request) {
                            CorsConfiguration config = new CorsConfiguration();

                            config.setAllowedOrigins(Collections.singletonList("https://field-training-7b3c6.web.app"));
                            config.setAllowedMethods(Collections.singletonList("*"));
                            config.setAllowCredentials(true);
                            config.setAllowedHeaders(Collections.singletonList("*"));
                            config.setMaxAge(3600L);
                            return config;
                        }
                    }))
                    .addFilterBefore(new JwtAuthenticationFilter(jwtTokenProvider, tokenBlacklistService), UsernamePasswordAuthenticationFilter.class)
                    .csrf().disable()

                    .authorizeHttpRequests((auth) -> auth
                    		.requestMatchers("/matching/**", "/mypage/**", "/attendance/**","/practice/**","/class/**","/operation/**","/union/**","/rating/**","/attendance/**"
                    				,"/api/managerInfo/**","/api/listmanagement/**","api/matchingcheck/match","/admin/**")
                            .hasAuthority("ROLE_APPROVAL")
                            .requestMatchers("/matching/**", "/mypage/**", "/attendance/**","/practice/**","/class/**","/operation/**","/union/**","/rating/**","/attendance/**")
                            .hasAnyAuthority("ROLE_STUDENT", "ROLE_TEACHER","ROLE_ADMIN" )
                            .requestMatchers("/admin/**").hasAnyAuthority("ROLE_ADMIN")
                            .requestMatchers("/api/managerInfo/**","/api/listmanagement/**","api/matchingcheck/match")
                            .hasAnyAuthority("ROLE_SCHOOL_MANAGER","ROLE_COLLEGE_MANAGER","ROLE_ADMIN")
                            .requestMatchers("/api/auth/logout", "/login", "/join/**", "/", "/find/**","/notice/list","/notice/detail","/notice/mainList","/reference/mainList"
                            		,"/api/gallery/recent","/api/gallery/galleries/paged","/api/gallery/{boardID}","/uploads/{filename}","/reference/list","/reference/detail","/form/list","/form/detail","/faq/list"
                            		,"/faq/detail","/api/calendar").permitAll()
                            .anyRequest().authenticated()
                    )
                   
                    .exceptionHandling(exceptionHandling -> exceptionHandling
                            .accessDeniedHandler(new CustomAccessDeniedHandler())
                            .authenticationEntryPoint(new CustomAuthenticationEntryPoint()))
                    .logout(logout -> logout
                            .logoutUrl("/logout")
                            .logoutSuccessHandler(customLogoutSuccessHandler())) 
                    .build();

		
	}
	
	private LogoutSuccessHandler customLogoutSuccessHandler() {
        return (HttpServletRequest request, HttpServletResponse response, Authentication authentication) -> {
            response.setContentType("application/json");
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write("{\"message\":\"Logout successful\"}");
        };
    }
	
}