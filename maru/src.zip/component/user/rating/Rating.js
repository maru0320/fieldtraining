import React from "react";

function Rating() {
    return <h1>평가</h1>;
  }

export default Rating;