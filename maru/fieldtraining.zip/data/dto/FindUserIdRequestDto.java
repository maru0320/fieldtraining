package com.fieldtraining.data.dto;

import lombok.Data;

@Data
public class FindUserIdRequestDto {
	private String name;
	private String email;
}
