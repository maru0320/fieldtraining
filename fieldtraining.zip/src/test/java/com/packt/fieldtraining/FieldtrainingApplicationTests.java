package com.packt.fieldtraining;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest
class FieldtrainingApplicationTests {

	@Test
	void contextLoads() {
	}

}
