package com.fieldtraining.matching.entity;

public enum MatchStatus {
	PENDING, // 대기 중
	APPROVED, // 승인됨
	REJECTED // 거절됨
}
