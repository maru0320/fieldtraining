import React from "react";

function RatingCheck() {
    return <h1>평가확인</h1>;
  }

export default RatingCheck;