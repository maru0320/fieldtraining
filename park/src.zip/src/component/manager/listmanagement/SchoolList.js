import { useEffect, useState } from "react";
import axios from "axios";

const SchoolList = () => {
    const [teachers, setTeachers] = useState([]);
    const [students, setStudents] = useState([]);
    const [matchingTeachers, setMatchingTeachers] = useState([]);
    const [selectedStudent, setSelectedStudent] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // 선생님 리스트 가져오기
    useEffect(() => {
        const fetchTeachers = async () => {
            try {
                setLoading(true);
                const response = await axios.get("http://localhost:8090/api/listmanagement/teachers");
                console.log("Teachers Data: ", response.data);
                setTeachers(response.data);
            } catch (err) {
                console.error("Error fetching teachers data", err);
                setError("선생 정보를 불러오는 중 문제가 발생했습니다.");
            } finally {
                setLoading(false);
            }
        };

        fetchTeachers();
    }, []);

    //학생 리스트 가져오기
    useEffect(() => {
        const fetchStudents = async () => {
            try {
                const response = await axios.get("http://localhost:8090/api/listmanagement/students");
                console.log("Students Data: ", response.data);
                setStudents(response.data);
            } catch (err) {
                console.error("Error fetching students data", err);
                setError("학생 정보를 불러오는 중 문제가 발생했습니다.");
            }
        };
        
            fetchStudents();
    }, []);

    // 학생 선택 시 매칭된 교사 정보를 가져오는 함수
    const handleStudentSelect = async (studentId) => {
        setSelectedStudent(studentId); // 선택한 학생 ID 저장

        try {
            const response = await axios.get(`http://localhost:8090/api/listmanagement/teachersForstudent?studentId=${studentId}`);
            setMatchingTeachers(response.data); // 매칭된 교사 리스트 상태 업데이트
        } catch (err) {
            setError("매칭된 교사를 불러오는 중 문제가 발생했습니다.");
        }
    };

    return (
        <div>
            {/* 선생 리스트 */}
            <div>
                <p>선생님 목록</p>
                <ul>
                    {teachers.length > 0 ? (
                        teachers.map((teacher, index) => (
                        <li key={index}>
                            <strong>{teacher.name}</strong><br />
                            이메일: {teacher.email}<br />
                            학교: {teacher.schoolName}<br />
                            과목: {teacher.subject}
                        </li>
                        ))
                    ) : (
                    <li>선생님 정보가 없습니다.</li>  // 선생님 정보가 없을 경우 메시지 표시
                    )}
                </ul>
            </div>
            {/* 학생 리스트가 뜨는 곳 */}
            <div>
                <p>학생 목록</p>
                <ul>
                    {students.length > 0 ? (
                    students.map((student) => (
                        <li
                            key={student.id}
                            onClick={() => handleStudentSelect(student.id)}
                        >
                            {student.name} - {student.email} - {student.college} - {student.phoneNumber}
                        </li>
                        ))
                    ) : (
                        <li>학생 정보가 없습니다.</li>
                    )}
                </ul>
            </div>
            {/* 선생 리스트 표시하는 곳 */}
            {selectedStudent && (
                <div>
                    <h3>{students.find((student) => student.id === selectedStudent)?.name} 학생의 매칭된 교사들</h3>
                    <ul>
                        {matchingTeachers.length > 0 ? (
                        matchingTeachers.map((teacher, index) => (
                            <li key={index}>
                                <strong>{teacher.name}</strong><br />
                                이메일: {teacher.email}<br />
                                학교: {teacher.schoolName}<br />
                                과목: {teacher.subject}
                            </li>
                            ))
                        ) : (
                            <li>매칭된 교사가 없습니다.</li>
                        )}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default SchoolList;