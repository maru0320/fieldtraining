import React, { useEffect, useState } from 'react'
import CollegeList from "./listmanagement/CollegeList";
import SchoolList from "./listmanagement/SchoolList";
import ManagerInfo from "./info/ManagerInfo";
import {jwtDecode} from 'jwt-decode';

const ManagerPage = () => {
    const [userRole, setUserRole] = useState(null); // 역할 저장
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
        const handleStorageChange = () => {
          const token = localStorage.getItem("token");
          if (token) {
            try {
              const decodedToken = jwtDecode(token);
              setUserRole(decodedToken.role); // 토큰에서 role 가져오기
              setIsLoggedIn(true);
            } catch (error) {
              console.error("JWT 디코딩 오류:", error);
              setIsLoggedIn(false);
            }
          } else {
            setIsLoggedIn(false);
          }
        };
    
        handleStorageChange(); // 초기화
    
        // storage 이벤트 리스너 등록
        window.addEventListener("storage", handleStorageChange);
    
        return () => {
          window.removeEventListener("storage", handleStorageChange);
        };
    }, []);

    return (
        <div>
            <ManagerInfo />
            {isLoggedIn ? (
                userRole === "COLLEGE_MANAGER" ? (
                    <CollegeList />
                ) : userRole === "SCHOOL_MANAGER" ? (
                    <SchoolList />
                ) : (
                    <p>권한이 없습니다.</p> // 알 수 없는 역할 처리
                )
            ) : (
                <p>로그인이 필요합니다.</p> // 로그인 상태가 아니면 표시
            )}
        </div>
    );
};

export default ManagerPage;