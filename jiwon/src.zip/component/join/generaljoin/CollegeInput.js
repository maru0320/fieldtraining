function CollegeInput() {

        return(
        <div>
            <input class="inputbox" type="search" name="schoolName" placeholder="학교명"/>
            <br></br>
            <input class="inputbox" type="text" name="department" placeholder="학과" />
        </div>
        );

}
export default CollegeInput;